# Tools

This directory contains script files to help simplify calling into the FoenixMGR. The `cmd` directory contains Windows/DOS style batch files. The `sh` directory contains Unix/Linux style shell scripts.
